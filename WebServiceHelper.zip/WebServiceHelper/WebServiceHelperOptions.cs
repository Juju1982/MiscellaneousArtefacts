﻿using System.Collections.Generic;

namespace MoneybarnWebServices
{
    public class WebServiceHelperOptions
    {
        public Dictionary<string, string> Headers { get; set; }
    }
}
