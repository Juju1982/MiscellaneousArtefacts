﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace MoneybarnWebServices
{
    public class WebError
    {
        public string Error { get; set; }
        public string Stack { get; set; }
    }
}
